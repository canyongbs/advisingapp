<?php

declare(strict_types=1);

namespace Pest\Arch\Support;

/**
 * @internal
 */
final class ReflectionClassForFunction
{
    // ..
}
