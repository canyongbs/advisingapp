<?php

namespace Spatie\Multitenancy\Jobs;

interface TenantAware
{
}
