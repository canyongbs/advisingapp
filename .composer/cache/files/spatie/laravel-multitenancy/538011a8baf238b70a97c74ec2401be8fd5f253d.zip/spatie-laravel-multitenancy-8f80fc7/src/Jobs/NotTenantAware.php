<?php

namespace Spatie\Multitenancy\Jobs;

interface NotTenantAware
{
}
