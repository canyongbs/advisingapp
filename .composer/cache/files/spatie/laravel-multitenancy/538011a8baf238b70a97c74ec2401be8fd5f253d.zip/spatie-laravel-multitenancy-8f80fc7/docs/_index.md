---
title: v3
slogan: An unopinionated multitenancy package for Laravel apps
githubUrl: https://github.com/spatie/laravel-multitenancy
branch: main
---
