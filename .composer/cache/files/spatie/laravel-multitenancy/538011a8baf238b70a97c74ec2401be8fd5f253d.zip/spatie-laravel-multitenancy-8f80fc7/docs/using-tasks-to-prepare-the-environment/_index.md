---
title: Using tasks to prepare the environment
weight: 3
---
