---
title: Requirements
weight: 3
---

This package requires **PHP 8.0+** and **Laravel 8.0+**.
