---
title: Changelog
weight: 6
---

All notable changes to laravel-multitenancy are documented [on GitHub](https://github.com/spatie/laravel-multitenancy/blob/master/CHANGELOG.md)
