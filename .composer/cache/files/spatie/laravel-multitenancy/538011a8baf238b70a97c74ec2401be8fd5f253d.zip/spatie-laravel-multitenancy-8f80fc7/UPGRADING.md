# From v2 to v3

There are no API changes between v2 and v3. There is one behaviour change where jobs that are `NotTenantAware` will forget any current tenant before processing.

# From v1 to v2

There are no API changes between v1 and v2. If you're on PHP 8, you should be able to upgrade without having to make any changes.
