<?php

namespace Spatie\LaravelSettings\Exceptions;

use Exception;

class CouldNotUnserializeSettings extends Exception
{
}
