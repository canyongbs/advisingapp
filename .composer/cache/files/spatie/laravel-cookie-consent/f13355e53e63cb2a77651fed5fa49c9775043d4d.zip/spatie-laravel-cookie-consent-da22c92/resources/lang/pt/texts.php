<?php

return [
    'message' => 'Este site utiliza cookies. Ao navegar no site estará a consentir a sua utilização.',
    'agree' => 'Aceitar',
];
