<?php

return [
    'message' => 'Din opplevelse på dette nettstedet vil bli forbedret ved å tillate informasjonskapsler (cookies).',
    'agree' => 'Tillat informasjonskapsler',
];
