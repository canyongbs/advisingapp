<?php

return [
    'message' => "Ce site nécessite l'autorisation de cookies pour fonctionner correctement.",
    'agree' => 'Accepter',
];
