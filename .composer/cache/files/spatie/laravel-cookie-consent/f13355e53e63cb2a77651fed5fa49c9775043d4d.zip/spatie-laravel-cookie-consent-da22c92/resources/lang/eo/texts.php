<?php

return [
    'message' => 'Tiu ĉi retejo uzas kuketojn por plibonigi vian sperton.',
    'agree' => 'Akcepti kuketojn',
];
