<?php

return [
    'message' => 'Diese Seite verwendet Cookies um das Nutzererlebnis zu steigern.',
    'agree' => 'Akzeptieren',
];
