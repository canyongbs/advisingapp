<?php

namespace Spatie\LaravelData\Support\Validation;

interface RequiringRule
{
}
