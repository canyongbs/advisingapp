---
title: v3
slogan: Powerful data objects for Laravel
githubUrl: https://github.com/spatie/laravel-data
branch: main
---
