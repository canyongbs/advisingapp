---
title: As a resource

weight: 3
---
