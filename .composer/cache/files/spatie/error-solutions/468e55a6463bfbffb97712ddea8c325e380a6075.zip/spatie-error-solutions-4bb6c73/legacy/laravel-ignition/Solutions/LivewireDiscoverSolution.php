<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\Laravel\LivewireDiscoverSolution as BaseLivewireDiscoverSolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class LivewireDiscoverSolution extends BaseLivewireDiscoverSolutionAlias  implements Solution
{

}
