<?php

namespace Spatie\LaravelIgnition\Support;

use Spatie\ErrorSolutions\Support\Laravel\StringComparator as BaseStringComparator;

class StringComparator extends BaseStringComparator
{

}
