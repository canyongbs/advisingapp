<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\Laravel\RunMigrationsSolution as BaseRunMigrationsSolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class RunMigrationsSolution extends BaseRunMigrationsSolutionAlias implements Solution
{

}
