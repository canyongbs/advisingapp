<?php

namespace Spatie\Ignition\Contracts;

class BaseSolution extends \Spatie\ErrorSolutions\Contracts\BaseSolution implements Solution
{
}
