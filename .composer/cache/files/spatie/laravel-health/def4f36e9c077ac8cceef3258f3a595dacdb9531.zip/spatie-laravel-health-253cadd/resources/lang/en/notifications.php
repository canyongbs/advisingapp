<?php

return [
    'laravel_health' => 'Laravel Health',

    'check_failed_mail_subject' => 'Some of the health checks on :application_name have failed',

    'check_failed_mail_body' => 'The following checks reported warnings and errors:',

    'check_failed_slack_message' => 'Some of the health checks on :application_name have failed.',

    'health_results' => 'Health Results',

    'check_results_from' => 'Check results from',
];
