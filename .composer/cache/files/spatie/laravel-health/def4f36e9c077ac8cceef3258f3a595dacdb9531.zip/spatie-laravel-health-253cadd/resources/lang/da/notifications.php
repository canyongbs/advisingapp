<?php

return [
    'laravel_health' => 'Laravel Health',

    'check_failed_mail_subject' => 'Nogle tjeks på :application_name mislykkedes',

    'check_failed_mail_body' => 'Følgende tjeks rapporterede advarsler og fejl:',

    'check_failed_slack_message' => 'Nogle tjeks på :application_name mislykkedes.',

    'health_results' => 'Health resultater',

    'check_results_from' => 'Tjek resultater fra',
];
