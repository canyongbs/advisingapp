<?php

return [
    'laravel_health' => 'Laravel Health',

    'check_failed_mail_subject' => 'Certains tests de :application_name ont échoué',

    'check_failed_mail_body' => 'Les tests suivants comportent des avertissements et des erreurs:',

    'check_failed_slack_message' => 'Certains tests de :application_name ont échoué.',

    'health_results' => 'Bilan de santé',

    'check_results_from' => 'Résultats des tests de',
];
