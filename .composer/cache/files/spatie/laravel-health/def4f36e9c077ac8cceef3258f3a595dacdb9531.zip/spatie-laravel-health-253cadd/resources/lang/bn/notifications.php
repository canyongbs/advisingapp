<?php

return [
    'laravel_health' => 'লারাভেল স্বাস্থ্য পরীক্ষা',

    'check_failed_mail_subject' => ':application_name এর কিছু স্বাস্থ্য পরীক্ষা ব্যর্থ হয়েছে',

    'check_failed_mail_body' => 'নিম্নলিখিত যাচাইকৃত সতর্কতা এবং ত্রুটি রিপোর্ট করা হয়েছে:',

    'check_failed_slack_message' => ':application_name এর কিছু স্বাস্থ্য পরীক্ষা ব্যর্থ হয়েছে।',

    'health_results' => 'স্বাস্থ্য পরীক্ষা ফলাফল',

    'check_results_from' => 'এখান থেকে ফলাফল যাচাই করুন',
];
