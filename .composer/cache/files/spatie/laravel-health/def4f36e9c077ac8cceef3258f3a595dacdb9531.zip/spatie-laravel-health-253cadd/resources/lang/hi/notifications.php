<?php

return [
    'laravel_health' => 'लारावेल स्वास्थ्य जाँच',

    'check_failed_mail_subject' => ':application_name पर कुछ स्वास्थ्य जाँचें विफल हो गई हैं।',

    'check_failed_mail_body' => 'निम्नलिखित जाँचों ने चेतावनी और त्रुटियों की सूचना दी:',

    'check_failed_slack_message' => ':application_name पर कुछ स्वास्थ्य जाँच विफल हो गई हैं।',

    'health_results' => 'स्वास्थ्य जाँच के परिणाम',

    'check_results_from' => 'परिणाम जाँचा गया है',
];
