# Changelog

All notable changes to `test-time` will be documented in this file

## 1.3.2 - 2023-01-10

- fix for latest versions of Carbon

## 1.3.1 - 2023-01-10

- accept timezone parameter

## 1.3.0 - 2022-02-04

Add `unfreeze`

## 1.2.2 - 2020-11-03

- add support for PHP 8

## 1.2.1 - 2020-07-16

- support `CarbonImmutable`

## 1.2.0 - 2020-02-23

- add `freezeAtSecond` method (#9)

## 1.1.3 - 2020-01-22

- support carbon 1.26

## 1.1.2 - 2019-06-14

- yet even more methods

## 1.1.1 - 2019-06-14

- moarrrrr docblocked methods

## 1.1.0 - 2019-06-12

- allow passing the format and time to `freeze`

## 1.0.0 - 2019-06-12

- initial release
