# Changelog

All notable changes to `pest-plugin-test-time` will be documented in this file.

## 2.0.0 - 2023-03-21

### What's Changed

- support Pest v2 by @freekmurze in https://github.com/spatie/pest-plugin-test-time/pull/2

### New Contributors

- @freekmurze made their first contribution in https://github.com/spatie/pest-plugin-test-time/pull/2

**Full Changelog**: https://github.com/spatie/pest-plugin-test-time/compare/1.1.1...2.0.0

## 1.1.1 - 2022-06-05

- allow `null` with `toBeCarbon`

## 1.1.0 - 2022-06-05

**Full Changelog**: https://github.com/spatie/pest-plugin-test-time/compare/1.0.0...1.1.0

## 1.0.0 - 2021-07-25

- initial release
