<?php

namespace Tiptap\Nodes;

use Tiptap\Core\Node;

class Document extends Node
{
    public static $name = 'doc';

    public static $topNode = true;
}
