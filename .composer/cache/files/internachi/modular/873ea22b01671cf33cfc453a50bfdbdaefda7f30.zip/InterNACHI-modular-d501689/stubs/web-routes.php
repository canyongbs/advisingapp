<?php

// use StubModuleNamespace\StubClassNamePrefix\Http\Controllers\StubClassNamePrefixController;

// Route::get('/StubModuleNamePlural', [StubClassNamePrefixController::class, 'index'])->name('StubModuleNamePlural.index');
// Route::get('/StubModuleNamePlural/create', [StubClassNamePrefixController::class, 'create'])->name('StubModuleNamePlural.create');
// Route::post('/StubModuleNamePlural', [StubClassNamePrefixController::class, 'store'])->name('StubModuleNamePlural.store');
// Route::get('/StubModuleNamePlural/{StubModuleNameSingular}', [StubClassNamePrefixController::class, 'show'])->name('StubModuleNamePlural.show');
// Route::get('/StubModuleNamePlural/{StubModuleNameSingular}/edit', [StubClassNamePrefixController::class, 'edit'])->name('StubModuleNamePlural.edit');
// Route::put('/StubModuleNamePlural/{StubModuleNameSingular}', [StubClassNamePrefixController::class, 'update'])->name('StubModuleNamePlural.update');
// Route::delete('/StubModuleNamePlural/{StubModuleNameSingular}', [StubClassNamePrefixController::class, 'destroy'])->name('StubModuleNamePlural.destroy');
