<?php

namespace StubModuleNamespace\StubClassNamePrefix\Tests;

class StubClassNamePrefixServiceProviderTest extends StubTestCaseBase
{
	// TODO
}
