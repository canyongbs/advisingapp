<?php

use Illuminate\Database\Migrations\Migration;

return new class() extends Migration {
	public function up()
	{
	}
	
	public function down()
	{
	}
};
