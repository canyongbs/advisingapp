<?php

namespace Modules\TestModule\Providers;

use Illuminate\Support\ServiceProvider;

class TestModuleServiceProvider extends ServiceProvider
{
	public function register()
	{
	}
	
	public function boot()
	{
	}
}
