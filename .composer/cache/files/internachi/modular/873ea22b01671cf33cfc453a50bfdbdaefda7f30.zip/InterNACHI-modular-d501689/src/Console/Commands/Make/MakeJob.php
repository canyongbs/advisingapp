<?php

namespace InterNACHI\Modular\Console\Commands\Make;

use Illuminate\Foundation\Console\JobMakeCommand;

class MakeJob extends JobMakeCommand
{
	use Modularize;
}
