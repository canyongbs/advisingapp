<?php

namespace InterNACHI\Modular\Console\Commands\Make;

use Illuminate\Foundation\Console\ResourceMakeCommand;

class MakeResource extends ResourceMakeCommand
{
	use Modularize;
}
