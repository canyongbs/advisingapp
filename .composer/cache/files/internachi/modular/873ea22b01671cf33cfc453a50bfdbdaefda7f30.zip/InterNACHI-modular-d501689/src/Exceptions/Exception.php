<?php

namespace InterNACHI\Modular\Exceptions;

class Exception extends \Exception
{
}
