<?php

namespace InterNACHI\Modular\Console\Commands\Make;

use Illuminate\Foundation\Console\PolicyMakeCommand;

class MakePolicy extends PolicyMakeCommand
{
	use Modularize;
}
