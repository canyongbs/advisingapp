<?php

namespace InterNACHI\Modular\Console\Commands\Make;

use Illuminate\Foundation\Console\RequestMakeCommand;

class MakeRequest extends RequestMakeCommand
{
	use Modularize;
}
