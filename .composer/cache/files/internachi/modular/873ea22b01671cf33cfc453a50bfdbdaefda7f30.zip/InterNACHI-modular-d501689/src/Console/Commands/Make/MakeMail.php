<?php

namespace InterNACHI\Modular\Console\Commands\Make;

use Illuminate\Foundation\Console\MailMakeCommand;

class MakeMail extends MailMakeCommand
{
	use Modularize;
}
