<?php

namespace InterNACHI\Modular\Console\Commands\Make;

use Illuminate\Foundation\Console\RuleMakeCommand;

class MakeRule extends RuleMakeCommand
{
	use Modularize;
}
