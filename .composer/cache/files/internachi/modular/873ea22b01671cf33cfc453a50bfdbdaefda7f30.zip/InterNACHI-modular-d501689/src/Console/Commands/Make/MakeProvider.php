<?php

namespace InterNACHI\Modular\Console\Commands\Make;

use Illuminate\Foundation\Console\ProviderMakeCommand;

class MakeProvider extends ProviderMakeCommand
{
	use Modularize;
}
