<?php

namespace InterNACHI\Modular\Console\Commands\Make;

use Illuminate\Foundation\Console\NotificationMakeCommand;

class MakeNotification extends NotificationMakeCommand
{
	use Modularize;
}
