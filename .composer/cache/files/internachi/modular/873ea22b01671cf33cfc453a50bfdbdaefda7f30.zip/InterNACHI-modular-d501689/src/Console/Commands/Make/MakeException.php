<?php

namespace InterNACHI\Modular\Console\Commands\Make;

use Illuminate\Foundation\Console\ExceptionMakeCommand;

class MakeException extends ExceptionMakeCommand
{
	use Modularize;
}
