<?php

namespace InterNACHI\Modular\Console\Commands\Make;

use Illuminate\Foundation\Console\ChannelMakeCommand;

class MakeChannel extends ChannelMakeCommand
{
	use Modularize;
}
