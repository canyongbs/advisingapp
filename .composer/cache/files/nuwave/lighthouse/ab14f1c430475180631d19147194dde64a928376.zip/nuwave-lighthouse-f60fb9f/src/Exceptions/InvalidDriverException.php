<?php declare(strict_types=1);

namespace Nuwave\Lighthouse\Exceptions;

class InvalidDriverException extends \Exception {}
