<?php declare(strict_types=1);

namespace Nuwave\Lighthouse\Federation;

class FederationException extends \Exception {}
