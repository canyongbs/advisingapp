<?php declare(strict_types=1);

namespace Laragraph\Utils;

use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

class BadRequestGraphQLException extends BadRequestHttpException
{
}
