<?php

return [
    'impersonating' => 'Vous êtes en train de vous faire passer pour',
    'leave' => 'Quitter',
];
