<?php

return [
    'label' => 'Peniruan',
];
