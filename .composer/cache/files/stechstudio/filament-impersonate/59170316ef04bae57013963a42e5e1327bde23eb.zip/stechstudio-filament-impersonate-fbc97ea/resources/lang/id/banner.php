<?php

return [
    'impersonating' => 'Anda sedang berpura-pura menjadi',
    'leave' => 'Tinggalkan',
];
