<?php

return [
    'label' => 'Imitieren',
];
