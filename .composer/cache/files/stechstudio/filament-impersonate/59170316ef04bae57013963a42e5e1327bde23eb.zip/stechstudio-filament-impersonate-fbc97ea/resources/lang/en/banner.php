<?php

return [
    'impersonating' => 'Impersonating user',
    'leave' => 'Leave',
];
