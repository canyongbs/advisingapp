<?php

return [
    'impersonating' => '사용자를 표시 중입니다.',
    'leave' => '원래 사용자로 돌아가기',
];
