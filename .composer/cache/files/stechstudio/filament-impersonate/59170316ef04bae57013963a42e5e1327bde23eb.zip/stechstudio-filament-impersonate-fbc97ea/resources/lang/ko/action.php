<?php

return [
    'label' => '사용자 가장하기',
];
