<?php

return [
    'label' => 'تقليد',
];
