<?php

return [
    'impersonating' => 'מתחזה למשתמש',
    'leave' => 'להתנתק',
];
