<?php

return [
    'label' => 'Átjelentkezés',
];
