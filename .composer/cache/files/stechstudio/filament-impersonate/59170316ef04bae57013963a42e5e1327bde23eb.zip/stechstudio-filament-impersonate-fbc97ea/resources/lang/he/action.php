<?php

return [
    'label' => 'להתחזות',
];
