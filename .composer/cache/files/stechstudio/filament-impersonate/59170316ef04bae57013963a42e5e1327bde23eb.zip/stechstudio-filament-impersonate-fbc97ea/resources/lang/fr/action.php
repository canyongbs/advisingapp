<?php

return [
    'label' => 'Se faire passer pour',
];
