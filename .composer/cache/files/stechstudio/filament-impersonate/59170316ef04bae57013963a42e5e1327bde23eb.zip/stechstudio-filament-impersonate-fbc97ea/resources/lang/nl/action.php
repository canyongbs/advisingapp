<?php

return [
    'label' => 'Inloggen als...',
];
