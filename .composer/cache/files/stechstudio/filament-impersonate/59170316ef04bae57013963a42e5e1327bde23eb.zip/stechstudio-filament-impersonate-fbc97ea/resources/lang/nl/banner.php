<?php

return [
    'impersonating' => 'Ingelogd als gebruiker',
    'leave' => 'Terug naar eigen account',
];
