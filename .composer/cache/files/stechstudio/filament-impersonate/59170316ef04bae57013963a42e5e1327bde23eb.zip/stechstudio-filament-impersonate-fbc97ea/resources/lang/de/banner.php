<?php

return [
    'impersonating' => 'Imitiere Benutzer',
    'leave' => 'Verlassen',
];
