<?php

return [
    'impersonating' => 'Belépve mint:',
    'leave' => 'Visszajelentkezés',
];
