<?php

return [
    'label' => 'Impersonate',
];
