<?php

return [
    'impersonating' => 'المستخدم المقلّد',
    'leave' => 'مغادرة',
];
