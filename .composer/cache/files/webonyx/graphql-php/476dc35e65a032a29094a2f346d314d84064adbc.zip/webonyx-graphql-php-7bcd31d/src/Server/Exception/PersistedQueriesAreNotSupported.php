<?php declare(strict_types=1);

namespace GraphQL\Server\Exception;

use GraphQL\Server\RequestError;

class PersistedQueriesAreNotSupported extends RequestError {}
