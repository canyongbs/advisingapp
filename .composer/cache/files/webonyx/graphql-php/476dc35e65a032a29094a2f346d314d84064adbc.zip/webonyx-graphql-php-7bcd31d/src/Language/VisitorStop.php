<?php declare(strict_types=1);

namespace GraphQL\Language;

final class VisitorStop extends VisitorOperation {}
