<?php

namespace Doctrine\DBAL\Exception;

/** @psalm-immutable */
class DatabaseDoesNotExist extends DatabaseObjectNotFoundException
{
}
