## Introduction

This package provides contracts
for [staudenmeir/eloquent-has-many-deep](https://github.com/staudenmeir/eloquent-has-many-deep):

- `ConcatenableRelation` makes
  a [third-party package](https://github.com/staudenmeir/eloquent-has-many-deep#third-party-packages) concatenable.
