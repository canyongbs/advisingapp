module.exports = {
    content: ["./resources/views/**/*.blade.php"],
    darkMode: "class",
    important: ".filament-spatie-health",
    plugins: [],
    corePlugins: {
      preflight: false,
    }
};
