<?php

return [

    'pages' => [
        'health_check_results' => [
            'buttons' => [
                'refresh' => 'Refrescar',
            ],

            'heading' => 'Salud de la aplicación',

            'navigation' => [
                'group' => 'Configuración',
                'label' => 'Salud de la aplicación',
            ],

            'notifications' => [
                'check_results' => 'Revisar resultados desde',
            ],
        ],
    ],
    
];
