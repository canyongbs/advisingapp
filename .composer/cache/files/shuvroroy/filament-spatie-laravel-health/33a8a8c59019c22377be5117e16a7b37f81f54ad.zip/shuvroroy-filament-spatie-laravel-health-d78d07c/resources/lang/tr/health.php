<?php

return [

    'pages' => [
        'health_check_results' => [
            'buttons' => [
                'refresh' => 'Yenile',
            ],

            'heading' => 'Uygulama Sağlığı',

            'navigation' => [
                'group' => 'Ayarlar',
                'label' => 'Uygulama Sağlığı',
            ],

            'notifications' => [
                'check_results' => 'Sonuçları kontrol et.',
            ],
        ],
    ],

];
