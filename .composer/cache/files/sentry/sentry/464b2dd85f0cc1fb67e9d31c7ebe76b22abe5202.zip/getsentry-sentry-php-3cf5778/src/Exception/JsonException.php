<?php

declare(strict_types=1);

namespace Sentry\Exception;

final class JsonException extends \Exception
{
}
