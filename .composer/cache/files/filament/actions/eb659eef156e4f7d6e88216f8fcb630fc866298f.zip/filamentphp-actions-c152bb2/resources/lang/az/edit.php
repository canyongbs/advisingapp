<?php

return [

    'single' => [

        'label' => 'Redaktə et',

        'modal' => [

            'heading' => ':label redaktə et',

            'actions' => [

                'save' => [
                    'label' => 'Yadda saxla',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Yadda saxlanıldı',
            ],

        ],

    ],

];
