<?php

return [

    'single' => [

        'label' => 'Végleges törlés',

        'modal' => [

            'heading' => ':label végleges törlése',

            'actions' => [

                'delete' => [
                    'label' => 'Törlés',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Törölve',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Kijelöltek végleges törlése',

        'modal' => [

            'heading' => 'Kijelölt :label végleges törlése',

            'actions' => [

                'delete' => [
                    'label' => 'Törlés',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Törölve',
            ],

        ],

    ],

];
