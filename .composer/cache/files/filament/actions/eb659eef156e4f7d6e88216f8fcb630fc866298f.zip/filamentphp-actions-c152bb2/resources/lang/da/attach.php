<?php

return [

    'single' => [

        'label' => 'Attach',

        'modal' => [

            'heading' => 'Vedhæft :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Record',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Vedhæft',
                ],

                'attach_another' => [
                    'label' => 'Vedhæft & vedhæft en mere',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Vedhæftet',
            ],

        ],

    ],

];
