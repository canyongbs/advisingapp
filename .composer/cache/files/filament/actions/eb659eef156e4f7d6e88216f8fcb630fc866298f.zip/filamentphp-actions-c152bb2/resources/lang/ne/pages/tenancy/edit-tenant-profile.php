<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'परिवर्तनहरू सेभ गर्नुहोस्',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'सेभ भयो',
        ],

    ],

];
