<?php

return [

    'single' => [

        'label' => 'İlişdir',

        'modal' => [

            'heading' => ':label ilişdir',

            'fields' => [

                'record_id' => [
                    'label' => 'Məlumat',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'İlişdir',
                ],

                'attach_another' => [
                    'label' => 'İlişdir və başqasına başla',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'İlişdirildi',
            ],

        ],

    ],

];
