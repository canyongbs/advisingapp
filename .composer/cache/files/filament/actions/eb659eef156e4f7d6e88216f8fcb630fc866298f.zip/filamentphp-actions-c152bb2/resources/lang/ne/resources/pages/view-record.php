<?php

return [

    'title' => 'हेर्नुहोस् :label',

    'breadcrumb' => 'हेर्नुहोस्',

    'content' => [

        'tab' => [
            'label' => 'हेर्नुहोस्',
        ],

    ],

];
