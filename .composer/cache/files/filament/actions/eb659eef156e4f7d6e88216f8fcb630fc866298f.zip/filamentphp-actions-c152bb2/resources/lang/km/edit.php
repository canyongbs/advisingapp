<?php

return [

    'single' => [

        'label' => 'កែសម្រួល',

        'modal' => [

            'heading' => 'កែសម្រួល :label',

            'actions' => [

                'save' => [
                    'label' => 'រក្សាទុកការផ្លាស់ប្តូរ',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'បានរក្សាទុក',
            ],

        ],

    ],

];
