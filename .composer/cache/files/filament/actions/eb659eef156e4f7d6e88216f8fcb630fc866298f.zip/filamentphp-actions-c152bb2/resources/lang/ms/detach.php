<?php

return [

    'single' => [

        'label' => 'Tanggalkan',

        'modal' => [

            'heading' => 'Tanggalkan :label',

            'actions' => [

                'detach' => [
                    'label' => 'Tanggalkan',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Ditanggalkan',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Tanggalkan pilihan',

        'modal' => [

            'heading' => 'Tanggalkan pilihan :label',

            'actions' => [

                'detach' => [
                    'label' => 'Tanggalkan pilihan',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Ditanggalkan',
            ],

        ],

    ],

];
