<?php

return [

    'single' => [

        'label' => 'Pogled',

        'modal' => [

            'heading' => 'Pogled :label',

            'actions' => [

                'close' => [
                    'label' => 'Zatvoriti',
                ],

            ],

        ],

    ],

];
