<?php

return [

    'single' => [

        'label' => 'Олшруулах',

        'modal' => [

            'heading' => 'Олшруулах :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Олшруулах',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Олшруулав',
            ],

        ],

    ],

];
