<?php

return [

    'single' => [

        'label' => 'ویرایش',

        'modal' => [

            'heading' => 'ویرایش :label',

            'actions' => [

                'save' => [
                    'label' => 'ذخیره',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'ذخیره شد',
            ],

        ],

    ],

];
