<?php

return [

    'single' => [

        'label' => 'Repliciraj',

        'modal' => [

            'heading' => 'Repliciraj :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Repliciraj',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Replicirano',
            ],

        ],

    ],

];
