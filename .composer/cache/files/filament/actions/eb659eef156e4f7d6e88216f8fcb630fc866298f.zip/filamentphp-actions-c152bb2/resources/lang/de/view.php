<?php

return [

    'single' => [

        'label' => 'Anzeigen',

        'modal' => [

            'heading' => ':label anzeigen',

            'actions' => [

                'close' => [
                    'label' => 'Schließen',
                ],

            ],

        ],

    ],

];
