<?php

return [

    'single' => [

        'label' => '분리',

        'modal' => [

            'heading' => ':label 분리',

            'actions' => [

                'dissociate' => [
                    'label' => '분리',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => '분리 완료',
            ],

        ],

    ],

    'multiple' => [

        'label' => '선택한 항목 분리',

        'modal' => [

            'heading' => '선택한 :label 분리',

            'actions' => [

                'dissociate' => [
                    'label' => '분리',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => '분리 완료',
            ],

        ],

    ],

];
