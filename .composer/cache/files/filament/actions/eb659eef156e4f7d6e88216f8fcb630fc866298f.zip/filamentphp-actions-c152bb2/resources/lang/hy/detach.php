<?php

return [

    'single' => [

        'label' => 'Անջատել',

        'modal' => [

            'heading' => 'Անջատել :label',

            'actions' => [

                'detach' => [
                    'label' => 'Անջատել',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Անջատվել է',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Անջատել ընտրվածը',

        'modal' => [

            'heading' => 'Անջատել ընտրված :label',

            'actions' => [

                'detach' => [
                    'label' => 'Անջատել ընտրվածը',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Անջատվել է',
            ],

        ],

    ],

];
