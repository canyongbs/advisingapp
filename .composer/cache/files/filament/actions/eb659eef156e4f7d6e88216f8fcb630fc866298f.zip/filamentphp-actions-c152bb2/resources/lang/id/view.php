<?php

return [

    'single' => [

        'label' => 'Lihat',

        'modal' => [

            'heading' => 'Lihat :label',

            'actions' => [

                'close' => [
                    'label' => 'Tutup',
                ],

            ],

        ],

    ],

];
