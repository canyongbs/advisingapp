<?php

namespace Filament\Support\Events;

use Illuminate\Foundation\Events\Dispatchable;

class FilamentUpgraded
{
    use Dispatchable;
}
