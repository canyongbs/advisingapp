<?php

return [

    'messages' => [
        'copied' => 'प्रतिलिपि गरियो',
    ],

];
