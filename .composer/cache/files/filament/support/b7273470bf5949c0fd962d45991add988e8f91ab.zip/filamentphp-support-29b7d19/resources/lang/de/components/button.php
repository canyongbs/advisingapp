<?php

return [

    'messages' => [
        'uploading_file' => 'Datei wird hochgeladen...',
    ],

];
