<?php

return [

    'messages' => [
        'copied' => 'অনুকৃত',
    ],

];
