<?php

return [

    'messages' => [
        'copied' => 'คัดลอกเรียบร้อย',
    ],

];
