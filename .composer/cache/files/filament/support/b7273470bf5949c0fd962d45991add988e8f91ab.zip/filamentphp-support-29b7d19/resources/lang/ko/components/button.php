<?php

return [

    'messages' => [
        'uploading_file' => '파일 업로드 ...',
    ],

];
