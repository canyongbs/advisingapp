<?php

return [

    'messages' => [
        'uploading_file' => 'Ֆայլի բեռնում...',
    ],

];
