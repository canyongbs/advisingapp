<?php

return [

    'messages' => [
        'copied' => 'Imeigwa',
    ],

];
