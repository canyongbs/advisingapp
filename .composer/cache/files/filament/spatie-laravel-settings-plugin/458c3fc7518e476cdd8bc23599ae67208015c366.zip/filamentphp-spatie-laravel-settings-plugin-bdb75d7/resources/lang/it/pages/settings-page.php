<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Salva',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Salvato',
        ],

    ],

];
