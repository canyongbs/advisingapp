<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Yadda saxla',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Yadda saxlanıldı',
        ],

    ],

];
