<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'O\'zgarishlarni saqlash',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Saqlandi',
        ],

    ],

];
