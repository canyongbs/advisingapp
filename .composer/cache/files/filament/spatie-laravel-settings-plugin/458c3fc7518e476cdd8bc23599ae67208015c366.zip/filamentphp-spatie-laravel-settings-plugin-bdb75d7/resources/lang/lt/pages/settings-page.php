<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Išsaugoti pakeitimus',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Išsaugota',
        ],

    ],

];
