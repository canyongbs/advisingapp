<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Spara ändringar',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Sparades',
        ],

    ],

];
