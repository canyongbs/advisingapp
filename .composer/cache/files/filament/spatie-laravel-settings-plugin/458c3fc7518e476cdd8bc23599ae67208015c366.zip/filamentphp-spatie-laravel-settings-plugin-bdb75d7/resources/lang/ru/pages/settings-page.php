<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Сохранить',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Сохранено',
        ],

    ],

];
