<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Uložit změny',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Uloženo',
        ],

    ],

];
