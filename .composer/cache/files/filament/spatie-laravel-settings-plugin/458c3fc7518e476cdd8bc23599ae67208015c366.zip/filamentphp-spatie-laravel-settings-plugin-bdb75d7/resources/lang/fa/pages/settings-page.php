<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'ذخیره',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'ذخیره شد',
        ],

    ],

];
