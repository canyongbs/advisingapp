<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Salvar',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Salvo',
        ],

    ],

];
