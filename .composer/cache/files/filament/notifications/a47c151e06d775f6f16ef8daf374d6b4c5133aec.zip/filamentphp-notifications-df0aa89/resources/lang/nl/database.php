<?php

return [

    'modal' => [

        'heading' => 'Meldingen',

        'actions' => [

            'clear' => [
                'label' => 'Wissen',
            ],

            'mark_all_as_read' => [
                'label' => 'Alles als gelezen markeren',
            ],

        ],

        'empty' => [
            'heading' => 'Geen meldingen',
            'description' => 'Kijk later nog eens.',
        ],

    ],

];
