<?php

return [

    'modal' => [

        'heading' => 'Arifa',

        'actions' => [

            'clear' => [
                'label' => 'Safisha',
            ],

            'mark_all_as_read' => [
                'label' => 'Weka alama zote kama zimesomwa',
            ],

        ],

        'empty' => [
            'heading' => 'Hakuna arifa hapa',
            'description' => 'Tafadhali angalia tena baadae',
        ],

    ],

];
