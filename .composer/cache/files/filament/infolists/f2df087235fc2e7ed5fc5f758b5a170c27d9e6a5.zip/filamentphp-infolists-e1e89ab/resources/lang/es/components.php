<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Mostrar :count menos',
                'expand_list' => 'Mostrar :count más',
            ],

            'more_list_items' => 'y :count más',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Clave',
                ],

                'value' => [
                    'label' => 'Valor',
                ],

            ],

            'placeholder' => 'No hay entradas',

        ],

    ],

];
