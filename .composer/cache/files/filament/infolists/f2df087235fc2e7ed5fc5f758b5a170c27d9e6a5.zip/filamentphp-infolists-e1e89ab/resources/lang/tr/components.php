<?php

return [

    'text_entry' => [
        'more_list_items' => 've :count daha',
    ],

];
