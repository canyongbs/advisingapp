<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Desar canvis',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Canvis desats',
        ],

    ],

];
