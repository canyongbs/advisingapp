<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Odhlásit se',
        ],

    ],

    'welcome' => 'Vítejte',

];
