<?php

return [

    'breadcrumb' => 'Saraksts',

];
