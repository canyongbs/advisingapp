<?php

return [

    'field' => [
        'label' => 'חיפוש גלובלי',
        'placeholder' => 'חיפוש',
    ],

    'no_results_message' => 'לא נמצאו תוצאות.',

];
