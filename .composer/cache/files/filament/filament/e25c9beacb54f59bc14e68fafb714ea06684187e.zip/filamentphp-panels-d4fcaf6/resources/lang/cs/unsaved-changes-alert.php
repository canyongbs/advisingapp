<?php

return [

    'body' => 'Máte neuložené změny. Opravdu chcete opustit tuto stránku?',

];
