<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'ドキュメント',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
