<?php

return [

    'field' => [
        'label' => 'ការស្វែងរកក្នុងប្រព័ន្ធទូទៅ',
        'placeholder' => 'ស្វែងរក',
    ],

    'no_results_message' => 'រកមិនឃើញលទ្ធផលនៃការស្វែងរកទេ។',

];
