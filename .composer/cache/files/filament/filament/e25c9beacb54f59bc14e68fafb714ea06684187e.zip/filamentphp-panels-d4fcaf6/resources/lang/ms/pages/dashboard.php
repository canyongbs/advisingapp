<?php

return [

    'title' => 'Papan pemuka',

    'actions' => [

        'filter' => [

            'label' => 'Penapis',

            'modal' => [

                'heading' => 'Penapis',

                'actions' => [

                    'apply' => [

                        'label' => 'Mohon',

                    ],

                ],

            ],

        ],

    ],

];
