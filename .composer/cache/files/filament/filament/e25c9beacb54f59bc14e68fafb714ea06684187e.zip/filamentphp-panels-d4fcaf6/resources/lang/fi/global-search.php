<?php

return [

    'field' => [
        'label' => 'Globaali haku',
        'placeholder' => 'Etsi',
    ],

    'no_results_message' => 'Hakutuloksia ei löytynyt.',

];
