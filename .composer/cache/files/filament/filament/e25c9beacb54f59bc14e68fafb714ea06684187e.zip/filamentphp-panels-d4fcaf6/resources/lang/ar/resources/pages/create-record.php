<?php

return [

    'title' => 'إضافة :label',

    'breadcrumb' => 'إضافة',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'إلغاء',
            ],

            'create' => [
                'label' => 'إضافة',
            ],

            'create_another' => [
                'label' => 'إضافة وبدء إضافة المزيد',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'تمت الإضافة',
        ],

    ],

];
