<?php

declare(strict_types=1);

namespace Spiral\RoadRunner\Message;

/**
 * @internal
 */
interface ControlMessage
{
}
