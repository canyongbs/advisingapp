<?php

declare(strict_types=1);

namespace Spiral\RoadRunner\Exception;

final class RoadRunnerException extends \RuntimeException
{
}
