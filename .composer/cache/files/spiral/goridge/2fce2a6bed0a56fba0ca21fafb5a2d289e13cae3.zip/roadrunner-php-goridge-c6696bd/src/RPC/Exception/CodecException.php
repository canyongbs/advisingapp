<?php

declare(strict_types=1);

namespace Spiral\Goridge\RPC\Exception;

class CodecException extends \RuntimeException
{
}
