<?php

declare(strict_types=1);

namespace Spiral\Goridge\Exception;

class HeaderException extends TransportException
{
}
