<?php

declare(strict_types=1);

namespace Spiral\Goridge\RPC\Exception;

class ServiceException extends RPCException
{
}
