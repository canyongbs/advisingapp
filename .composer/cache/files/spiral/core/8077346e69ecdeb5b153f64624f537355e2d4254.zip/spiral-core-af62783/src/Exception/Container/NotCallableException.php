<?php

declare(strict_types=1);

namespace Spiral\Core\Exception\Container;

class NotCallableException extends ContainerException
{
}
