<?php

declare(strict_types=1);

namespace Spiral\Core\Attribute;

/**
 * @internal
 */
interface Plugin
{
}
