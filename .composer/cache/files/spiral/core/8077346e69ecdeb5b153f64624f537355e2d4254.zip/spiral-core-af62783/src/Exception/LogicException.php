<?php

declare(strict_types=1);

namespace Spiral\Core\Exception;

/**
 * Generic logic exception raised in spiral components.
 */
class LogicException extends \LogicException
{
}
