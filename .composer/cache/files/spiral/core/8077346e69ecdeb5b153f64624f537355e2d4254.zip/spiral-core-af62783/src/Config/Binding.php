<?php

declare(strict_types=1);

namespace Spiral\Core\Config;

use Stringable;

/**
 * @internal
 */
abstract class Binding implements Stringable
{
}
