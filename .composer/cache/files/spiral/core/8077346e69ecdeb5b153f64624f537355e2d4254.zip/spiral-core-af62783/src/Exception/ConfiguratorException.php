<?php

declare(strict_types=1);

namespace Spiral\Core\Exception;

/**
 * Configuration specific exceptions.
 */
class ConfiguratorException extends LogicException
{
}
