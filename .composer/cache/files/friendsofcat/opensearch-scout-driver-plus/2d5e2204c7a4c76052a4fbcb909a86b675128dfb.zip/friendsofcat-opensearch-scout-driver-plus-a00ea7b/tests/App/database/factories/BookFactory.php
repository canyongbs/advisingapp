<?php declare(strict_types=1);

use Carbon\Carbon;
use Faker\Generator as Faker;
use Illuminate\Database\Eloquent\Factory;
use OpenSearch\ScoutDriverPlus\Tests\App\Author;
use OpenSearch\ScoutDriverPlus\Tests\App\Book;

/** @var Factory $factory */
$factory->define(Book::class, static fn (Faker $faker) => [
    'title' => $faker->sentence(5),
    'description' => $faker->realText(),
    'price' => $faker->randomNumber(3),
    'published' => Carbon::createFromFormat('Y-m-d', $faker->date('Y-m-d')),
    'tags' => $faker->words(random_int(1, 5)),
]);

$factory->afterMakingState(Book::class, 'belongs_to_author', static function (Book $book) {
    $book->author_id = factory(Author::class)->create()->id;
});
