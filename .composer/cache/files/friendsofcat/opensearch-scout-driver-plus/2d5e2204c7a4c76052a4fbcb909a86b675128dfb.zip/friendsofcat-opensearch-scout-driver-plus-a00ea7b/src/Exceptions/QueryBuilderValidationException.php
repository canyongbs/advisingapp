<?php declare(strict_types=1);

namespace OpenSearch\ScoutDriverPlus\Exceptions;

use RuntimeException;

final class QueryBuilderValidationException extends RuntimeException
{
}
