<?php declare(strict_types=1);

return [
    'refresh_documents' => env('OPENSEARCH_SCOUT_DRIVER_REFRESH_DOCUMENTS', false),
];
