# Changelog

All notable changes to `model-state-machine` will be documented in this file.

## 0.2.0 - 2022-09-18

- 💥 Rename `DefaultState` to `InitialState`
- 🎨 Some minor improvements

## 0.1.0 - 2022-04-23

- 🎉 initial release
