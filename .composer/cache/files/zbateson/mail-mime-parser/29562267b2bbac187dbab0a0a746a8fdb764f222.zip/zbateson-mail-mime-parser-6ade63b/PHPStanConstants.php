<?php

define ('TEST_DATA_DIR', __DIR__ . '/tests/_data');
define ('TEST_OUTPUT_DIR', __DIR__ . '/tests/_output');
