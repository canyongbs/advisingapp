<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQL\Testing\Package\Data\Types;

/**
 * @internal
 */
class CustomType {
    public function __invoke(): mixed {
        return null;
    }
}
