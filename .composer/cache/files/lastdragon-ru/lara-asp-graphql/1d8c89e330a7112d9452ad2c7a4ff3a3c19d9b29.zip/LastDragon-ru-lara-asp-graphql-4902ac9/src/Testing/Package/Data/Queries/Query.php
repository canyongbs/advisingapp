<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQL\Testing\Package\Data\Queries;

/**
 * @internal
 */
class Query {
    public function __invoke(): mixed {
        return null;
    }
}
