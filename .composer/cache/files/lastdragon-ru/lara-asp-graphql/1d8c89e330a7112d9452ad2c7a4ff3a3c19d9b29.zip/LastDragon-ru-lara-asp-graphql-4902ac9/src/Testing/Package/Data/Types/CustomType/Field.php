<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQL\Testing\Package\Data\Types\CustomType;

/**
 * @internal
 */
class Field {
    public function __invoke(): mixed {
        return null;
    }
}
