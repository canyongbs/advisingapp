<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQL\Exceptions;

use LastDragon_ru\LaraASP\GraphQL\PackageException;

abstract class AstException extends PackageException {
    // empty
}
