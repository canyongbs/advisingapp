<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQL\SearchBy\Contracts;

use LastDragon_ru\LaraASP\GraphQL\Builder\Contracts\Scope as ScopeContract;

interface Scope extends ScopeContract {
    // empty
}
