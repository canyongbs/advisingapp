<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\Serializer\Normalizers;

use Symfony\Component\Serializer\Context\Normalizer\AbstractObjectNormalizerContextBuilder;

class SerializableNormalizerContextBuilder extends AbstractObjectNormalizerContextBuilder {
    // empty
}
