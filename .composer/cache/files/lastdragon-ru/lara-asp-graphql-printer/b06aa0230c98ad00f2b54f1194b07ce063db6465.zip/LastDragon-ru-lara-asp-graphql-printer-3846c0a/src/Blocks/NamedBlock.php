<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQLPrinter\Blocks;

/**
 * @internal
 */
interface NamedBlock {
    public function getName(): string;
}
