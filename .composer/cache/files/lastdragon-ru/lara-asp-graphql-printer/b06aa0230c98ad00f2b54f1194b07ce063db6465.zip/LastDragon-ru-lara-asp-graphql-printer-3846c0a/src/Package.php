<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQLPrinter;

final class Package {
    public const Name = 'lara-asp-graphql-printer';
}
