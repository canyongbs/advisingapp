<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQLPrinter\Blocks\Types;

/**
 * @internal
 */
interface TypeDefinitionBlock {
    // empty
}
