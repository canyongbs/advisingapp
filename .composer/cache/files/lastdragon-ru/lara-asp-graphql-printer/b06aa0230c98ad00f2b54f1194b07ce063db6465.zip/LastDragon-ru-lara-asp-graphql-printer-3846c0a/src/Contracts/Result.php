<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQLPrinter\Contracts;

use Stringable;

interface Result extends Statistics, Stringable {
    // empty
}
