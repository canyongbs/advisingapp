<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\GraphQLPrinter\Settings;

class DefaultSettings extends ImmutableSettings {
    // empty
}
