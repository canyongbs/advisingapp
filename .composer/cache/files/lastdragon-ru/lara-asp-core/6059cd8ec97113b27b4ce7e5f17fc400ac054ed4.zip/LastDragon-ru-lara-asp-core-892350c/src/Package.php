<?php declare(strict_types = 1);

namespace LastDragon_ru\LaraASP\Core;

final class Package {
    public const Name = 'lara-asp-core';
}
