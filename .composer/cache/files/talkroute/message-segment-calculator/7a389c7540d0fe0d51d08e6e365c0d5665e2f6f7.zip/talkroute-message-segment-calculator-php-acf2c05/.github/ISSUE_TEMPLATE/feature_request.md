---
name: Feature request
about: Issues pertaining new features, or augmentations to existing features
title: "[FEATURE] "
labels: feature
assignees: ''

---

## Overview
<!-- Provide an overview of the feature being proposed, and what an acceptable solution would look like, at a high level -->

### Is your feature request related to an existing issue? Please describe.
<!-- A clear and concise description of what the problem is. Delete this section if this is not related to any existing issues. -->

## Acceptance Criteria
<!-- Provide acceptance criteria that must be met for an issue to be resolved -->
- [ ]