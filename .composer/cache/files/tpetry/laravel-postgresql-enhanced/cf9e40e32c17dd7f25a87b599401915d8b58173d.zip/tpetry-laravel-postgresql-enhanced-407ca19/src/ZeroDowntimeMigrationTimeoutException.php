<?php

declare(strict_types=1);

namespace Tpetry\PostgresqlEnhanced;

use Exception;

class ZeroDowntimeMigrationTimeoutException extends Exception
{
}
