<?php declare(strict_types=1);

namespace Kelunik\Certificate;

class FieldNotSupportedException extends \Exception
{
}
