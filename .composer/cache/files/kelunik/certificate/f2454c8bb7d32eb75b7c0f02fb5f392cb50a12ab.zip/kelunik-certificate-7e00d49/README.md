# certificate

[![License](https://img.shields.io/badge/license-MIT-blue.svg?style=flat-square)](https://github.com/kelunik/certificate/blob/master/LICENSE)

Access certificate details and transform between different formats.

**Required PHP Version**

- PHP 7.0+

**Installation**

```bash
composer require kelunik/certificate
```
