<?php

namespace Livewire;

use Livewire\Features\SupportFormObjects\Form as BaseForm;

class Form extends BaseForm
{
    //
}
