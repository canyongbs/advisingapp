<?php

namespace Laravel\Octane\Exceptions;

use Exception;

class ServerShutdownException extends Exception
{
}
