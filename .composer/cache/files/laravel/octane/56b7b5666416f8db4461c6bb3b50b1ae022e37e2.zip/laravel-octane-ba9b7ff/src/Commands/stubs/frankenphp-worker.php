<?php

require __DIR__.'/../vendor/laravel/octane/bin/frankenphp-worker.php';
