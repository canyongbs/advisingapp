<?php

namespace Laravel\Pennant\Events;

class AllFeaturesPurged
{
    //
}
