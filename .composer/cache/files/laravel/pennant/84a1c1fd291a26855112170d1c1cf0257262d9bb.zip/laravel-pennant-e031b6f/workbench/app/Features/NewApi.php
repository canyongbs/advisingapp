<?php

namespace Workbench\App\Features;

class NewApi
{
    public function resolve(mixed $scope)
    {
        return 'new-api-value';
    }
}
