<?php

namespace Workbench\App\Models;

use Illuminate\Foundation\Auth\User as Authenticable;

class User extends Authenticable
{
    protected $guarded = [];
}
