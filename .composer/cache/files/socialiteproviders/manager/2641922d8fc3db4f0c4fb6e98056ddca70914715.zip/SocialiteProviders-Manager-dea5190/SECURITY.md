# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 4.x   |:white_check_mark:                |
| 3.x  | :white_check_mark: |
| < 3.0   | :x:                |


## Reporting a Vulnerability

To report a vulnerability, please email atymicq@gmail.com and I will address your report as soon as possible.
