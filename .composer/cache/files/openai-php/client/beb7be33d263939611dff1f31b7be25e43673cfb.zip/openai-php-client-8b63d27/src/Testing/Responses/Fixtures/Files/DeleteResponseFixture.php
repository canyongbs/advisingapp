<?php

namespace OpenAI\Testing\Responses\Fixtures\Files;

final class DeleteResponseFixture
{
    public const ATTRIBUTES = [
        'id' => 'file-XjGxS3KTG0uNmNOK362iJua3',
        'object' => 'file',
        'deleted' => true,
    ];
}
