<?php

namespace League\OAuth1\Client\Credentials;

class TemporaryCredentials extends Credentials implements CredentialsInterface
{
}
