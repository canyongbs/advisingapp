<?php

namespace OwenIt\Auditing\Exceptions;

use Exception;

class AuditingException extends Exception
{
}
