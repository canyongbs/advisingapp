<?php

namespace OwenIt\Auditing\Contracts;

interface AttributeModifier
{
    //
}
