<?php

declare (strict_types=1);
namespace Rector\Php70\Exception;

use Exception;
final class InvalidEregException extends Exception
{
}
