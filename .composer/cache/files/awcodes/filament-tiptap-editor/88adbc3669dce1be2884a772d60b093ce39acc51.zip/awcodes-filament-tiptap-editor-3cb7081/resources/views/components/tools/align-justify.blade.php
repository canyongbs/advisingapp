<x-filament-tiptap-editor::button
    action="editor().chain().focus().setTextAlign('justify').run()"
    active="{ textAlign: 'justify' }"
    label="{{ trans('filament-tiptap-editor::editor.align_justify') }}"
    icon="align-justify"
/>
