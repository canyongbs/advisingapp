<x-filament-tiptap-editor::button
    action="editor().chain().focus().setHorizontalRule().run()"
    active="horizontalRule"
    label="{{ trans('filament-tiptap-editor::editor.hr') }}"
    icon="hr"
/>