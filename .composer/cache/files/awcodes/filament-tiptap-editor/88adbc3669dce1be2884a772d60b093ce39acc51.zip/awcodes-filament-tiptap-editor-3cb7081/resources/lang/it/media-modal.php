<?php

return [
    'heading' => [
        'update' => 'Aggiorna Media',
        'insert' => 'Inserisci Media',
    ],
    'buttons' => [
        'cancel' => 'Annulla',
        'insert' => 'Inserisci',
    ],
    'labels' => [
        'file' => 'File',
        'link_text' => 'Testo del Link',
        'alt' => 'Testo Alternativo',
        'alt_helper_text' => 'Scopri come descrivere lo scopo dell\'immagine.',
        'title' => 'Titolo',
        'lazy' => 'Caricamento Lazy',
    ],

];
