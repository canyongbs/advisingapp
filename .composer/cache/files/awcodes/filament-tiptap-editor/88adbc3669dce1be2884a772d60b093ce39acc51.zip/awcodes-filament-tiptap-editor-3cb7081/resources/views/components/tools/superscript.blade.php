<x-filament-tiptap-editor::button
    action="editor().chain().focus().toggleSuperscript().run()"
    active="superscript"
    label="{{ trans('filament-tiptap-editor::editor.superscript') }}"
    icon="superscript"
/>