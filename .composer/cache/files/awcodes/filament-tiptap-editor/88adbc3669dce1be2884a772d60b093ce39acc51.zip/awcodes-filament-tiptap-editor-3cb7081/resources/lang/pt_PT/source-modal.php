<?php

return [
    'heading' => 'Editar Código Fonte',
    'buttons' => [
        'cancel' => 'Cancelar',
        'update' => 'Atualizar',
    ],
    'labels' => [
        'source' => 'Código Fonte',
    ],
];
