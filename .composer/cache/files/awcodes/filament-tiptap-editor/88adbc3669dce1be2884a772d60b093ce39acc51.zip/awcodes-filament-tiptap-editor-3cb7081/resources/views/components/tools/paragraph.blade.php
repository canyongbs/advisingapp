<x-filament-tiptap-editor::button
    action="editor().chain().focus().setParagraph().run()"
    active="paragraph"
    label="{{ trans('filament-tiptap-editor::editor.paragraph') }}"
    icon="paragraph"
/>