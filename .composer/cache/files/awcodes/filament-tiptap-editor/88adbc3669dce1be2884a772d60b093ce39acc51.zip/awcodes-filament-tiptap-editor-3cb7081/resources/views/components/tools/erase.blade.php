<x-filament-tiptap-editor::button
    action="editor().commands.clearContent(true)"
    label="{{ trans('filament-tiptap-editor::editor.erase') }}"
    icon="erase"
/>
