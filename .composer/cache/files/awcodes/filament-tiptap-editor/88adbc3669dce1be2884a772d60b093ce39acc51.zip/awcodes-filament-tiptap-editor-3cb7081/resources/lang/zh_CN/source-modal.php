<?php

return [
    'heading' => '编辑源代码',
    'buttons' => [
        'cancel' => '取消',
        'update' => '更新',
    ],
    'labels' => [
        'source' => '来源',
    ],
];
