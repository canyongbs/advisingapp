<?php

return [
    'heading' => 'Generatore di Griglie',
    'labels' => [
        'submit' => 'Inserisci Griglia',
        'columns' => 'Colonne',
        'stack_at' => 'Stack At',
        'asymmetric' => 'Asimmetrico',
        'asymmetric_left' => 'Span Colonna Sinistra',
        'asymmetric_right' => 'Span Colonna Destra',
        'dont_stack' => 'Non Stackare',
    ],

];
