<x-filament-tiptap-editor::button
    action="editor().chain().focus().toggleCode().run()"
    active="code"
    label="{{ trans('filament-tiptap-editor::editor.code') }}"
    icon="code"
/>