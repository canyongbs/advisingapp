<x-filament-tiptap-editor::button
    action="editor().chain().focus().toggleUnderline().run()"
    active="underline"
    label="{{ trans('filament-tiptap-editor::editor.underline') }}"
    icon="underline"
/>