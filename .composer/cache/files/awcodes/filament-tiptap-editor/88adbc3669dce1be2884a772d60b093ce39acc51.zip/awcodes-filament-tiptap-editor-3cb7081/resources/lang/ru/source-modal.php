<?php

return [
    'heading' => 'Редактировать исходный код',
    'buttons' => [
        'cancel' => 'Отмена',
        'update' => 'Обновить',
    ],
    'labels' => [
        'source' => 'Исходник',
    ],
];
