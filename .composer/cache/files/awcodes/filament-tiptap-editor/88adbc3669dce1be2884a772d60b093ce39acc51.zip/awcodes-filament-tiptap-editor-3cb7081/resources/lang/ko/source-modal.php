<?php

return [
    'heading' => '소스 코드 편집',
    'buttons' => [
        'cancel' => '취소',
        'update' => '업데이트',
    ],
    'labels' => [
        'source' => '소스',
    ],
];
