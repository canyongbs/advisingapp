<x-filament-tiptap-editor::button
    action="editor().chain().focus().toggleBlockquote().run()"
    active="blockquote"
    label="{{ trans('filament-tiptap-editor::editor.blockquote') }}"
    icon="blockquote"
/>
