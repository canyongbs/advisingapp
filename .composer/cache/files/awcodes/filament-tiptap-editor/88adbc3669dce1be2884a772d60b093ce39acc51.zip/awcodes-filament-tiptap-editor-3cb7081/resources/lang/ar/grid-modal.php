<?php

return [
    'heading' => 'منشئ الشبكة',
    'labels' => [
        'submit' => 'إدراج شبكة',
        'columns' => 'الأعمدة',
        'stack_at' => 'تجميع عند',
        'asymmetric' => 'غير متناسق',
        'asymmetric_left' => 'اتساع العمود الأيسر',
        'asymmetric_right' => 'اتساع العمود الأيمن',
        'dont_stack' => 'منع التجميع',
    ],
];
