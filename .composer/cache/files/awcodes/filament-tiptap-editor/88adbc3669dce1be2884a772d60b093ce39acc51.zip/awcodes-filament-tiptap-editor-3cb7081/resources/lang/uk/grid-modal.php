<?php

return [
    'heading' => 'Конструктор сітки',
    'labels' => [
        'submit' => 'Вставити сітку',
        'columns' => 'Колонки',
        'stack_at' => 'Рівень складання',
        'asymmetric' => 'Асиметрично',
        'asymmetric_left' => 'Розмах лівої колонки',
        'asymmetric_right' => 'Розмах правої колонки',
        'dont_stack' => 'Не складати',
    ],
];
