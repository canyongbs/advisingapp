<?php

return [
    'heading' => 'Constructeur de Grille',
    'labels' => [
        'submit' => 'Insérer la Grille',
        'columns' => 'Colonnes',
        'stack_at' => 'Empiler à',
        'asymmetric' => 'Asymétrique',
        'asymmetric_left' => 'Extension de la Colonne Gauche',
        'asymmetric_right' => 'Extension de la Colonne Droite',
        'dont_stack' => 'Ne pas Empiler',
    ],
];
