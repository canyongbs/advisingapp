<x-filament-tiptap-editor::button
    action="editor().chain().focus().toggleHighlight().run()"
    active="highlight"
    label="{{ trans('filament-tiptap-editor::editor.highlight') }}"
    icon="highlight"
/>