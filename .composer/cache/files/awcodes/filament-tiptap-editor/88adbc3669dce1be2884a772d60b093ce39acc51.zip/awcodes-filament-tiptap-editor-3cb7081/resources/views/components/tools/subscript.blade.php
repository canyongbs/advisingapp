<x-filament-tiptap-editor::button
    action="editor().chain().focus().toggleSubscript().run()"
    active="subscript"
    label="{{ trans('filament-tiptap-editor::editor.subscript') }}"
    icon="subscript"
/>