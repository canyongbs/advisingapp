<?php

return [
    'heading' => 'Grid Builder',
    'labels' => [
        'submit' => 'Insert Grid',
        'columns' => 'Columns',
        'stack_at' => 'Stack At',
        'asymmetric' => 'Asymmetric',
        'asymmetric_left' => 'Left Column Span',
        'asymmetric_right' => 'Right Column Span',
        'dont_stack' => 'Don\'t Stack',
    ],
];
