<x-filament-tiptap-editor::button
    action="editor().chain().focus().redo().run()"
    active="redo"
    label="{{ trans('filament-tiptap-editor::editor.redo') }}"
    icon="redo"
/>
