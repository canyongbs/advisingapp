<?php

return [
    'heading' => [
        'update' => 'Media bijwerken',
        'insert' => 'Media invoegen',
    ],
    'buttons' => [
        'cancel' => 'Annuleren',
        'insert' => 'Invoegen',
    ],
    'labels' => [
        'file' => 'Bestand',
        'link_text' => 'Linktekst',
        'alt' => 'Alt-tekst',
        'alt_helper_text' => 'Leer hoe je het doel van de afbeelding beschrijft.',
        'title' => 'Titel',
    ],
];
