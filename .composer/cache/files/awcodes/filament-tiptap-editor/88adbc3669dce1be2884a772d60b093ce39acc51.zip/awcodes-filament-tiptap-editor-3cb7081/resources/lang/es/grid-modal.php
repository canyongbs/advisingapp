<?php

return [
    'heading' => 'Constructor de Cuadrícula',
    'labels' => [
        'submit' => 'Insertar Cuadrícula',
        'columns' => 'Columnas',
        'stack_at' => 'Apilar en',
        'asymmetric' => 'Asimétrico',
        'asymmetric_left' => 'Extensión de Columna Izquierda',
        'asymmetric_right' => 'Extensión de Columna Derecha',
        'dont_stack' => 'No Apilar',
    ],
];
