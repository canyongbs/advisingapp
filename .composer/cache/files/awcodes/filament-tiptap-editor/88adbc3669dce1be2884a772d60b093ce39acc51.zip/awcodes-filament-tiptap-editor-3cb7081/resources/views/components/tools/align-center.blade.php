<x-filament-tiptap-editor::button
    action="editor().chain().focus().setTextAlign('center').run()"
    active="{ textAlign: 'center' }"
    label="{{ trans('filament-tiptap-editor::editor.align_center') }}"
    icon="align-center"
/>