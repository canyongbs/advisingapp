<?php

return [
    'heading' => 'Редагувати код',
    'buttons' => [
        'cancel' => 'Скасувати',
        'update' => 'Оновити',
    ],
    'labels' => [
        'source' => 'Код',
    ],
];
