<?php

return [
    'heading' => '网格生成器',
    'labels' => [
        'submit' => '插入网格',
        'columns' => '列',
        'stack_at' => '堆叠',
        'asymmetric' => '不对称',
        'asymmetric_left' => '左列跨度',
        'asymmetric_right' => '右列跨度',
        'dont_stack' => '不要堆叠',
    ],
];
