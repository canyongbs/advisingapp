<?php

return [
    'heading' => 'Конструктор сетки',
    'labels' => [
        'submit' => 'Вставить сетку',
        'columns' => 'Колонки',
        'stack_at' => 'Уровень сложения',
        'asymmetric' => 'Асимметрично',
        'asymmetric_left' => 'Размах левой колонки',
        'asymmetric_right' => 'Размах правой колонки',
        'dont_stack' => 'Не складывать',
    ],
];
