<?php

namespace Maatwebsite\Excel\Concerns;

interface WithFormatData
{
}
