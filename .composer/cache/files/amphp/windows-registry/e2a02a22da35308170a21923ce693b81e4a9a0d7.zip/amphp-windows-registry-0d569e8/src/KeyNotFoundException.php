<?php declare(strict_types=1);

namespace Amp\WindowsRegistry;

final class KeyNotFoundException extends \Exception
{
}
