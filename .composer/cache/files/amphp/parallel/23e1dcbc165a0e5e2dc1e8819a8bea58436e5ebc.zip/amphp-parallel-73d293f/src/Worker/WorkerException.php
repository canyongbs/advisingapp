<?php declare(strict_types=1);

namespace Amp\Parallel\Worker;

class WorkerException extends \Exception
{
}
