<?php declare(strict_types=1);

namespace Amp\Dns;

class InvalidNameException extends DnsException
{
}
