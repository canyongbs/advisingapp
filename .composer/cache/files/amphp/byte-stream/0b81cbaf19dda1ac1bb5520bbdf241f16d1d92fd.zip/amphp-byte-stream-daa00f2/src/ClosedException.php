<?php declare(strict_types=1);

namespace Amp\ByteStream;

final class ClosedException extends StreamException
{
}
