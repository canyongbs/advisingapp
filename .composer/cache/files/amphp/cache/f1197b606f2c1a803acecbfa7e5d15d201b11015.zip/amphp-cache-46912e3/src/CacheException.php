<?php declare(strict_types=1);

namespace Amp\Cache;

/**
 * MUST be thrown in case a cache operation fails.
 */
class CacheException extends \Exception
{
}
