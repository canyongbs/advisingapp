<?php declare(strict_types=1);

namespace Amp\Process;

class ProcessException extends \Exception
{
}
