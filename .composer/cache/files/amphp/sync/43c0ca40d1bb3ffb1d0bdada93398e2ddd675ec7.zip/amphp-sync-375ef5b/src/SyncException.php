<?php declare(strict_types=1);

namespace Amp\Sync;

class SyncException extends \Exception
{
}
