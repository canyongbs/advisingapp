<?php declare(strict_types=1);

namespace Amp\Socket;

/**
 * Thrown if connecting fails.
 */
class ConnectException extends SocketException
{
}
