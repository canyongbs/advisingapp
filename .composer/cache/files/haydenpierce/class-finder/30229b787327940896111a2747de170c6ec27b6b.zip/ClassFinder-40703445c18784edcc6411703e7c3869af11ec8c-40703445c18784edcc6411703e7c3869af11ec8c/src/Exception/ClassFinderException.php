<?php

namespace HaydenPierce\ClassFinder\Exception;

class ClassFinderException extends \Exception
{

}
